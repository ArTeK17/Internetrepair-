# Internetrepair-
InternetRepair is a lightweight that diagnoses and repairs common internet connectivity issues. It   offers one-click fixes for DNS flush, adapter reset, TCP/IP/Winsock reset, IP renewal, ping/traceroute tests, firewall  and proxy checks, and browser-specific repairs. Includes detailed reports, scheduled maintenance.
