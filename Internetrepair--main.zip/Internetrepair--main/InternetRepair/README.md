# Internet Repair

A network troubleshooting tool with GUI and command-line interfaces that performs:
- DNS flush
- Winsock reset  
- TCP/IP stack reinitialization
- Connection test

Supports English, French, and Spanish interfaces with automatic language detection.

##Available Versions

### 1. **GUI Version (Recommended)**
- **File:** `InternetRepair.GUI.exe`
- **Features:** 
  - Modern graphical interface with checkboxes
  - Real-time status indicators
  - Selective operations (choose what to repair)
  - Visual success/failure feedback
  - Automatic administrator elevation prompt
  - Multi-language support (auto-detected)
  - No console window required

### 2. **Command Line Version**
- **File:** `InternetRepair.exe` (compiled from enhanced script)
- **Features:**
  - Selective operations via parameters: `-DnsOnly`, `-WinsockOnly`, `-TcpIpOnly`
  - Detailed logging to file
  - Verbose mode (`-Verbose`)
  - Custom log file path (`-LogFile <path>`)
  - No restart option (`-NoRestart`)
  - Comprehensive help system (`-Help` or `-?`)
  - Improved error handling and reporting

### 3. **Basic Version**
- **File:** `InternetRepair.ps1` (PowerShell script)
- **Features:** Simple automated repair sequence (requires manual execution)

##Quick Start

### For GUI Version (Double-click to run):
1. **Right-click** `InternetRepair.GUI.exe` → **Run as administrator**
2. Check/uncheck the boxes for desired operations:
   - ☑️ DNS Flush
   - ☑️ Winsock Reset  
   - ☑️ TCP/IP Reset
3. Click **"Repair Network"** button
4. Watch real-time status updates (green = success, red = failure)
5. Click **OK** on completion dialog

### For Command Line Version:
1. **Right-click** PowerShell → **Run as administrator**
2. Navigate to folder:
3. Run examples:
   ```powershell
   # Full repair (default)
   .\InternetRepair.exe
   
   # DNS flush only
   .\InternetRepair.exe -DnsOnly
   
   # Network stack reset only
   .\InternetRepair.exe -WonsockOnly -TcpIpOnly
   
   # With verbose logging
   .\InternetRepair.exe -Verbose
   
   # Custom log file
   .\InternetRepair.exe -LogFile "C:\Temp\repair.log"
   ```

#Advanced Features (Command Line Only)

### Selective Operations:
- `-DnsOnly` - Perform only DNS flush (`ipconfig /flushdns`)
- `-WonsockOnly` - Perform only Winsock reset (`netsh winsock reset`)
- `-TcpIpOnly` - Perform only TCP/IP reset (`netsh int ip reset`)

### Logging & Output:
- `-Verbose` - Display detailed progress in console
- `-LogFile <path>` - Specify custom log file location (default: `%TEMP%\InternetRepair_YYYYMMDD_HHMMSS.log`)
- Log files contain timestamps, operation status, and error details

### Options:
- `-NoRestart` - Skip 1-second delays between operations (faster execution)
- `-Help` or `-?` - Show detailed help information

##Language Support

The application automatically detects your system language and displays in:
- **English** (en)
- **Français** (fr) 
- **Español** (es)

Language detection happens on first run and is stored for future launches.

##Administrator Privileges

*Required for all operations** - The tool needs admin rights to:
- Flush DNS cache
- Reset Winsock catalog
- Reset TCP/IP stack
- Test network connectivity

If not run as administrator:
- GUI version: Shows elevation prompt then restarts with admin rights
- Command line version: Displays error message and exits

## Safety & Reliability

- **Non-destructive**: Only performs standard Windows network reset operations
- **Reversible**: All changes can be reverted through normal Windows network reset
- **Safe defaults**: All operations selected by default in GUI
- **Error handling**: Clear success/failure indicators for each operation
- **Logging**: Detailed audit trail for troubleshooting

##Requirements

- Windows 7 or later
- Administrator privileges (for network operations)
- No additional software required (standalone executable)

##Troubleshooting

### Common Issues:
1. **"Access denied" errors** → Always run as administrator
2. **Anti-virus false positives** → Some AVs flag PS2EXE-generated files (safe to ignore)
3. **No internet after repair** → Reboot may be required for full effect
4. **DNS not resolving** → Try flushing DNS again or check DNS server settings

### Log Files:
Check `%TEMP%\InternetRepair_*.log` for detailed operation history

##Tips

- For best results, run the full repair (all three operations) periodically
- If experiencing specific issues, use selective operations:
  - DNS problems → Use `-DnsOnly`
  - Connection/Limited access → Use `-WonsockOnly -TcpIpOnly`
- The GUI version remembers your last selections for convenience
- Consider creating a desktop shortcut to the .exe for easy access

##Support

For issues or feature requests, please refer to the project documentation.
The tool is designed to be safe, reliable, and user-friendly for both 
novice users and IT professionals.

---
**Version:** 2.0.0 (GUI Enhanced)  
**Last Updated:** July 2026  
**Compatible:** Windows 7, 8, 10, 11  
**Architecture:** x86/x64 (AnyCPU)
